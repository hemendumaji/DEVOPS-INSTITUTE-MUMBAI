# 10. Bash scripting - Penguin cipher

Bash scripting is something I have been avoiding for a long time.
Partly because I believe that my programming language of choice, Go, is almost as handy when it comes to scripting, and partly because I think that Bash syntax looks horrible.
Can’t knock it till you try it, so here I am trying to learn Bash scripting.

[This](https://www.howtogeek.com/67469/the-beginners-guide-to-shell-scripting-the-basics/) was a nice introduction, and after finding [this](https://devhints.io/bash) cool cheatsheet I felt comfortable trying to create a project.

The project ended up being a cipher program I called *Penguin cipher* after Linux’s mascot.
It allows you to encrypt text into something like this: *MTExIDIxMSAzMTMgNDAyIDQ2OCA0NjQgMTU5IDI0MSAyMzAgMzY3IDM3NCA1MjYgMTM3IDIyMiAyOTUgMzYzIDQzNCA0MzUg*

![](screenshot.png)
